ReadMe: Mdb2Rinex 
---------------------------------------------------------------------------------------------

Note: By using this tool, you agree to the SW license agreement which can be found here: https://leica-geosystems.com/legal-documents

For Windows users: 
- Go to the folder in which mdb2rinex is located. 
- Open a command prompt window (cmd).
- Use the tool as described below.

USAGE: ./mdb2rinex -f filename - o Output directory
Allowed Options:
 Options:
  -h [ --help ]         Print help messages
  -v [ --version ]      Print program version
  -s [ --summary ]      Print tracking summary at end of obs file
  -o [ --out ] arg      Output directory
  -f [ --files ] arg    Mdb input file list
  -r [ --rinex_version ] arg (=rinex3.04)
                                        Rinex version
                                        Supported values:
                                        rinex3.04
                                        rinex4.00
										
BEHAVIOUR:
There will be always only one output file per RINEX file type. When multiple input files are given, then the content will be concatenated per each file type. 

Examples:
	> ./mdb2rinex -f Mdba.m00 -o Rinex-out => To convert one MDB input file to one output file per RINEX file type
        > ./mdb2rinex -f Mdba.m00 Mdbb.m00 Mdbc.m00 -o Rinex-out => To convert multiple input files to only one output file per RINEX file type
        > ./mdb2rinex -f * -o Rinex-out => To convert multiple input files (without writing all filenames) contained in the Input directory to only one output file per RINEX file type
        > ./mdb2rinex -f MDB/Mdba.m00 MDB/Mdbb.m00 MDB/Mdbc.m00 -o Rinex-out => To convert multiple input files to only one output file per RINEX file type (the Input files are contained in a subfolder named MDB)
        > ./mdb2rinex -f MDB/* -o Rinex-out => To convert multiple input files (without writing all filenames) contained in the Input directory to only one output file per RINEX file type (the Input files are contained in a subfolder named MDB)

FILE NAME CREATION:
RINEX filename is set according the following logic:
- ssssdddhmm.yyt (with hourly file sequence character 'h' and starting minute 'mm') is set when data length is < 30 minutes and start/end times within same 30 minutes
- ssssdddf.yyt (with hourly file sequence character 'f' ['a', 'b', .. 'x']) is set when start/end times are accross the mid of a GPS hour (e.g: m25-m30, m20-m35, etc...)
- ssssdddf.yyt (with hourly file sequence character 'f' ['a', 'b', .. 'x']) is set when data length is < 12 hours and start/end times within same 12 hours
- ssssdddf.yyt (with daily file sequence number 'f' = 0 (zero)) is set when data length is >= 12 hours 
- ssssdddf.yyt (with daily file sequence number 'f' = 0 (zero)) is set when start/end times are accross the mid of a GPS day (e.g: l-m, k-n, etc...)

METEO AND AUXILIARY DATA:
If the input MDB file contains any MET(meteorological sensor) records, a RINEX meteorological ("m") file will be included in the output files.
If the input MDB file contains any AUX (e.g. tilt sensor) records, a RINEX auxiliary ("a") file will be included in the output files. 

VERSION HISTORY:
>> v0.0.4.0000 
 - Supports MDB files from RefWorx FW up to v4.11. The output version is RINEX 3.02. 
>> v0.0.5.0000 
 - Supports MDB files from RefWorx FW v4.11 up to v4.31. The output version is RINEX 3.02. 
>> v0.0.6.0000 
 - Supports MDB files from RefWorx FW v4.11 and later versions. 
 - Added option "-s [ --summary ]" to optionally output tracking summary at end of obs file, which previously was always output. 
 - First version provided for both Linux and Windows OS.
>> v4.97.35L 
 - Supports MDB files from RefWorx FW v4.11 up to at least v4.52. 
 - The output version is RINEX 3.04. 
 - Added signal support for BDS B1c/B2a, GLO L3. 
 - New versioning scheme has been introduced. 
 - Fixed problem concerning corrupted GLO navigation file. 
 - Windows version no longer requires external DLL files.
>> v5.6.29 WIN/LINUX(August 2022): 
 - Supports MDB files from RefWorx FW v4.11 up to at least v4.60. 
 - Added signal support for BDS B2b, GPS L1C, QZSS L1C. 
 - LINUX builds available for 32bit and 64bit distribution, and glibc v2.29 and later is required.
>> v5.6.46 WIN s(December 2022):
 - Fixed problem regarding converting multiple input files (without writing all filenames).
>> v6.0.358 WIN/LINUX(January 2024): 
 - Windows builds are available for both 32-bit and 64-bit architectures.
 - For LINUX, Ubuntu distribution 22.04 or later is required, or alternatively, glibc v2.35 or later is required.
 - Added support for RINEX 4.00. The default output version is RINEX 3.04.